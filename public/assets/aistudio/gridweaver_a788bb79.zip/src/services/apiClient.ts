import { GridTopology, RestorationPlan, SimulationMetrics } from '../models/grid';

export interface HealthCheckResponse {
  status: 'healthy' | 'degraded';
  version: string;
  solverEngines: {
    qiskitAerAvailable: boolean;
    classicalMipAvailable: boolean;
    gpuAcceleration: boolean;
  };
}

export interface SimulateScenarioRequest {
  failedNodeIds: string[];
  failedEdgeIds: string[];
  failedTowerIds: string[];
  backupCapacityMw: number;
}

export interface SimulateScenarioResponse {
  topology: GridTopology;
  metrics: SimulationMetrics;
  reachabilityMap: Record<string, boolean>;
}

export interface SolveRestorationRequest {
  topology: GridTopology;
  backupCapacityMw: number;
  objectiveWeightCritical: number;
  maxSwitchingSteps: number;
  timeLimitSec?: number;
}

export interface ClassicalSolverResponse {
  planId: string;
  method: 'classical_mip';
  solverName: string; // e.g. "COIN-OR CBC / HiGHS Branch-and-Cut"
  optimal: boolean;
  objectiveValue: number;
  runtimeMs: number;
  plan: RestorationPlan;
}

export interface QAOASolverResponse {
  planId: string;
  method: 'quantum_qaoa';
  ansatzDepthP: number;
  qubitCount: number;
  quantumSimulator: string; // e.g. "Qiskit Aer AerSimulator(statevector)"
  costHamiltonianTerms: number;
  approximationRatio: number;
  runtimeMs: number;
  plan: RestorationPlan;
  circuitSummary: {
    numQubits: number;
    depth: number;
    numGates: number;
  };
}

export interface CompareScenariosRequest {
  baselineScenarioId: string;
  comparisonScenarioIds: string[];
}

export interface CompareScenariosResponse {
  metricsComparison: Array<{
    scenarioName: string;
    totalDemandServedMw: number;
    criticalDemandServedMw: number;
    activeFailures: number;
    backupFuelUsedMw: number;
    switchingSteps: number;
  }>;
}

class GridWeaverApiClient {
  private baseUrl: string;
  private isConnected: boolean = false;

  constructor(baseUrl: string = 'http://localhost:8000') {
    this.baseUrl = baseUrl;
  }

  public getBaseUrl(): string {
    return this.baseUrl;
  }

  public setBaseUrl(url: string) {
    this.baseUrl = url;
  }

  public async checkHealth(): Promise<HealthCheckResponse | null> {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2000);
      const res = await fetch(`${this.baseUrl}/health`, { credentials: 'omit', signal: controller.signal });
      clearTimeout(timeoutId);
      if (res.ok) {
        this.isConnected = true;
        return await res.json();
      }
      this.isConnected = false;
      return null;
    } catch {
      this.isConnected = false;
      return null;
    }
  }

  public isBackendOnline(): boolean {
    return this.isConnected;
  }

  public async simulateScenario(req: SimulateScenarioRequest): Promise<SimulateScenarioResponse | null> {
    if (!this.isConnected) return null;
    try {
      const res = await fetch(`${this.baseUrl}/api/scenarios/simulate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req),
      });
      if (res.ok) return await res.json();
      return null;
    } catch {
      return null;
    }
  }

  public async solveClassicalMIP(req: SolveRestorationRequest): Promise<ClassicalSolverResponse | null> {
    if (!this.isConnected) return null;
    try {
      const res = await fetch(`${this.baseUrl}/api/restoration/solve-classical`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req),
      });
      if (res.ok) return await res.json();
      return null;
    } catch {
      return null;
    }
  }

  public async solveQuantumQAOA(req: SolveRestorationRequest): Promise<QAOASolverResponse | null> {
    if (!this.isConnected) return null;
    try {
      const res = await fetch(`${this.baseUrl}/api/quantum/solve-qaoa`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req),
      });
      if (res.ok) return await res.json();
      return null;
    } catch {
      return null;
    }
  }

  public async compareScenarios(req: CompareScenariosRequest): Promise<CompareScenariosResponse | null> {
    if (!this.isConnected) return null;
    try {
      const res = await fetch(`${this.baseUrl}/api/compare`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req),
      });
      if (res.ok) return await res.json();
      return null;
    } catch {
      return null;
    }
  }
}

export const gridWeaverApi = new GridWeaverApiClient();
