import React, { useState } from 'react';
import { 
  Cpu, 
  Server, 
  Binary, 
  GitFork, 
  RefreshCw, 
  AlertCircle, 
  CheckCircle2, 
  ShieldAlert, 
  Sparkles,
  ExternalLink,
  Code2
} from 'lucide-react';
import { gridWeaverApi } from '../../services/apiClient';

export const QuantumSolverPage: React.FC = () => {
  const [isChecking, setIsChecking] = useState(false);
  const [backendStatus, setBackendStatus] = useState<'offline' | 'online' | 'untested'>('untested');
  const [backendUrl, setBackendUrl] = useState('http://localhost:8000');

  const checkConnection = async () => {
    setIsChecking(true);
    gridWeaverApi.setBaseUrl(backendUrl);
    const health = await gridWeaverApi.checkHealth();
    setIsChecking(false);
    if (health && health.status === 'healthy') {
      setBackendStatus('online');
    } else {
      setBackendStatus('offline');
    }
  };

  return (
    <div className="flex-1 h-full overflow-y-auto bg-[#090d16] p-6 lg:p-8 space-y-6 text-slate-100 select-none">
      {/* Header */}
      <div className="pb-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-purple-400" />
            <h1 className="text-xl font-bold tracking-tight text-white">
              Hybrid Quantum-Classical Optimization Integration
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            FastAPI, NetworkX, and Qiskit QAOA backend bridge for combinatorial grid restoration.
          </p>
        </div>

        {/* Backend Status Badge */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono">
          <Server className="w-4 h-4 text-amber-400" />
          <span className="text-slate-400">Status:</span>
          <span className="text-amber-300 font-bold">
            {backendStatus === 'online' ? 'Backend Connected' : 'Backend Not Connected (Demo Mode)'}
          </span>
        </div>
      </div>

      {/* Prominent Truth-in-Science Disclosure */}
      <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
        <div className="text-xs text-slate-300 leading-relaxed">
          <strong className="text-white">Scientific Scope & Integrity:</strong> In this frontend prototype phase, all solver results are clearly denoted as <em className="text-cyan-300">"Backend Not Connected"</em>. Real QUBO Hamiltonian sampling and Qiskit Aer simulation will be conducted via the Python backend. No simulated quantum runtime or fictitious quantum speedup is fabricated.
        </div>
      </div>

      {/* Backend Connection Diagnostics Box */}
      <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
        <h2 className="text-sm font-semibold text-white flex items-center gap-2">
          <Server className="w-4 h-4 text-cyan-400" />
          Python FastAPI Backend Service Connection
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="sm:col-span-2">
            <label className="text-[11px] text-slate-400 block mb-1">
              Backend Service Endpoint URL
            </label>
            <input
              type="text"
              value={backendUrl}
              onChange={(e) => setBackendUrl(e.target.value)}
              placeholder="http://localhost:8000"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex items-end">
            <button
              onClick={checkConnection}
              disabled={isChecking}
              className="w-full py-2 px-4 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-medium text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin' : ''}`} />
              <span>{isChecking ? 'Pinging Service...' : 'Ping /health Endpoint'}</span>
            </button>
          </div>
        </div>

        {backendStatus === 'offline' && (
          <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-600/30 text-xs text-amber-200 flex items-center gap-2 font-mono">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Connection returned offline. Run <code className="text-amber-300 font-bold">uvicorn main:app --port 8000</code> in your Python backend environment to activate live QAOA solving.</span>
          </div>
        )}
      </div>

      {/* QUBO Mathematical Formulation Card */}
      <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4 font-mono text-xs">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <h2 className="text-sm font-semibold text-white font-sans flex items-center gap-2">
            <Binary className="w-4 h-4 text-purple-400" />
            QUBO Formulation Matrix & Decision Variables
          </h2>
          <span className="text-[11px] text-purple-400 font-mono">
            7 Binary Decision Variables [x₀ ... x₆]
          </span>
        </div>

        <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2 text-slate-300">
          <div className="text-cyan-300 font-bold">
            Objective Hamiltonian: H(x) = - &sum; w_i &middot; P_i &middot; x_i + &lambda;_cap &sum; (Violations)&sup2; + &lambda;_rad &sum; (Cycles)
          </div>
          <div className="text-[11px] text-slate-400 font-sans leading-relaxed">
            Where each binary variable represents circuit breaker and standby generator states:
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 text-[11px]">
            <div className="p-2 rounded bg-slate-900 border border-slate-800">
              <span className="text-cyan-400 font-bold">x₀:</span> Line TL-501 (500 kV Hydro Bulk)
            </div>
            <div className="p-2 rounded bg-slate-900 border border-slate-800">
              <span className="text-cyan-400 font-bold">x₁:</span> Line TL-201 (230 kV Inter-Substation)
            </div>
            <div className="p-2 rounded bg-slate-900 border border-slate-800">
              <span className="text-cyan-400 font-bold">x₂:</span> Line STL-691 (69 kV South Backbone)
            </div>
            <div className="p-2 rounded bg-slate-900 border border-slate-800">
              <span className="text-cyan-400 font-bold">x₃:</span> Tie-Line TL-692 (69 kV Cross-Tie Switch)
            </div>
            <div className="p-2 rounded bg-slate-900 border border-slate-800">
              <span className="text-cyan-400 font-bold">x₄:</span> Microgrid Tie MF-01 (Water-Hospital)
            </div>
            <div className="p-2 rounded bg-slate-900 border border-slate-800">
              <span className="text-cyan-400 font-bold">x₅:</span> Standby Diesel Generator (St. Jude Trauma)
            </div>
          </div>
        </div>
      </div>

      {/* QAOA Quantum Circuit Architecture */}
      <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
        <h2 className="text-sm font-semibold text-white flex items-center gap-2">
          <GitFork className="w-4 h-4 text-purple-400" />
          QAOA Quantum Ansatz Specification
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
            <span className="text-slate-400">Ansatz Depth (p-layers)</span>
            <div className="text-lg font-bold text-purple-300">p = 3 layers</div>
            <div className="text-[10px] text-slate-500">Alternating cost & mixer gates</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
            <span className="text-slate-400">Target Quantum Simulator</span>
            <div className="text-lg font-bold text-cyan-300">Qiskit Aer</div>
            <div className="text-[10px] text-slate-500">AerSimulator(method='statevector')</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
            <span className="text-slate-400">Classical Solver Baseline</span>
            <div className="text-lg font-bold text-emerald-400">HiGHS / CBC MIP</div>
            <div className="text-[10px] text-slate-500">Branch-and-Cut benchmark</div>
          </div>
        </div>
      </div>
    </div>
  );
};
